import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Header.css";
const Header = () => {
  const [userName, setUserName] = useState("");

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users/1")
      .then((response) => {
        setUserName(response.data.firstName);
      })
      .catch((error) => console.error("Error fetching data: ", error));
  }, []);
  return (
    <div>
      <div className="headerContainer">
        <h1>NAME</h1>
        <p>hello, {userName}</p>
      </div>
    </div>
  );
};

export default Header;
