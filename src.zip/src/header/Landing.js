import React, { useState } from "react";
import axios from "axios";

const Landing = () => {
  const [flightData, setFlightData] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const from = formData.get("from");
    const destination = formData.get("destination");
    const departureDate = formData.get("departureDate");

    axios
      .get(
        `https://your-api-url.com/flights?from=${from}&destination=${destination}&date=${departureDate}`
      )
      .then((response) => {
        setFlightData(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
        setFlightData(null);
      });
  };

  return (
    <div>
      <div className="searchbar_container">
        <form method="post" onSubmit={handleSubmit}>
          <label className="label" htmlFor="from">
            From
          </label>
          <select name="from" className="selection" aria-label="from" id="from">
            <option value="London Heathrow Airport">
              London Heathrow Airport
            </option>
            <option value="London Gatwick Airport">
              London Gatwick Airport
            </option>
            <option value="London Stansted Airport">
              London Stansted Airport
            </option>
          </select>
          <label className="label" htmlFor="destination">
            Destination
          </label>
          <select
            name="destination"
            className="selection"
            aria-label="destination"
            id="destination"
          >
            <option value="Paris Charles de Gaulle Airport">
              Paris Charles de Gaulle Airport
            </option>
            <option value="Amsterdam Airport Schiphol">
              Amsterdam Airport Schiphol
            </option>
            <option value="Frankfurt Airport">Frankfurt Airport</option>
          </select>
          <label className="label" htmlFor="departureDate">
            Departure date
          </label>
          <input
            id="departureDate"
            className="selection"
            type="date"
            name="departureDate"
          />
          <button type="submit" className="search_button">
            Search
          </button>
        </form>
      </div>
      {flightData && (
        <div>
          <h2>Flight Information</h2>
          <p>From: {flightData.from}</p>
          <p>To: {flightData.to}</p>
          <p>Departure Date: {flightData.departureDate}</p>
          {/* Add more details as needed */}
        </div>
      )}
    </div>
  );
};

export default Landing;
