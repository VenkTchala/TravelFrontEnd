import React from "react";

const DataComponent = ({ data }) => {
  if (!data || !data.offer) {
    return <div>No data available</div>;
  }
  return (
    <div>
      <p>{data.date}</p>
      <p> {data.offer.origin} </p>
      <p> {data.offer.originCity}</p>
      <p>{data.offer.destination}</p>
      <p>{data.offer.destinationCity}</p>
      <p>{data.offer.airline}</p>
      <p>{data.offer.available}</p>
      <p>{data.offer.connections}</p>
      <p>{data.offer.price}</p>
      <p>{data.remainingSeats}</p>
    </div>
  );
};

export default DataComponent;
