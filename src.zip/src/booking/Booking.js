import React, { useEffect, useState } from "react";
import axios from "axios";
import DataComponent from "./DataComponent";
import Landing from "../header/Landing";

const Booking = () => {
  const [jsonData, setJsonData] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => {
        if (Array.isArray(response.data)) {
          setJsonData(response.data);
        } else {
          console.error("Invalid data format: expected array");
        }
      })
      .catch((error) => console.error("Error fetching data: ", error));
  }, []);

  return (
    <div>
      <div className="bookingContainer">
        <Landing />
        {jsonData.map((item) => (
          <DataComponent key={item.id} data={item} />
        ))}
      </div>
    </div>
  );
};

export default Booking;
