import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Signup from "./login/Signup";
import Login from "./login/Login";
import Booking from "./booking/Booking";
import Header from "./header/Header";
import "./App.css";

const App = () => {
  return (
    <Router>
      <div className="mainContainer">
        <Header />
        <div className="heroContainer">
          <Routes>
            <Route path="/" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/booking" element={<Booking />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
